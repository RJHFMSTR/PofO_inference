#ifndef __MEMORYINFO_H__
#define __MEMORYINFO_H__

#include "StringBasics.h"

String & MemoryInfo(double bytes);

#endif
